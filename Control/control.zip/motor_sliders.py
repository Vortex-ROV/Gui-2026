from PySide6.QtCore import QObject

# Motor index -> which RC channel it lives on (1-based)
# Based on ArduSub servo config:
# SERVO3 = Motor6 = CH3
# SERVO4 = Motor5 = CH4
# SERVO5 = Motor3 = CH5
# SERVO6 = Motor1 = CH6
# SERVO7 = Motor4 = CH7
# SERVO8 = Motor2 = CH8
MOTOR_TO_CHANNEL = {
    0: 6,  # Motor1 -> CH6
    1: 8,  # Motor2 -> CH8
    2: 5,  # Motor3 -> CH5
    3: 7,  # Motor4 -> CH7
    4: 4,  # Motor5 -> CH4
    5: 3,  # Motor6 -> CH3
}

class MotorSliders(QObject):

    def __init__(self, ui, pixhawk):
        super().__init__()
        self.pixhawk = pixhawk

        self.motor_sliders = [
            ui.motor1, ui.motor2, ui.motor3,
            ui.motor4, ui.motor5, ui.motor6,
        ]
        self.motor_labels = [
            ui.motor1number, ui.motor2number, ui.motor3number,
            ui.motor4number, ui.motor5number, ui.motor6number,
        ]

        for i, slider in enumerate(self.motor_sliders):
            slider.setMinimum(1100)
            slider.setMaximum(1900)
            slider.setValue(1500)
            slider.setSingleStep(10)

            slider.valueChanged.connect(
                lambda val, lbl=self.motor_labels[i]: lbl.setText(str(val))
            )
            slider.valueChanged.connect(
                lambda val, idx=i: self._on_slider_changed(idx, val)
            )
            slider.sliderReleased.connect(
                lambda s=slider, idx=i: self._reset_slider(s, idx)
            )

    def _on_slider_changed(self, motor_index, pwm_value):
        self._send_individual(motor_index, pwm_value)

    def _reset_slider(self, slider, motor_index):
        slider.blockSignals(True)
        slider.setValue(1500)
        slider.blockSignals(False)
        self._send_individual(motor_index, 1500)

    def _send_individual(self, motor_index, pwm_value):
        """
        Send RC override for ONE motor only.
        Every other channel is explicitly set to 1500 (neutral)
        so no other thruster is affected.
        """
        # Start with all 8 channels at neutral
        ch = [1500] * 8

        # Only change the one channel that belongs to this motor
        target_ch = MOTOR_TO_CHANNEL[motor_index]  # 1-based channel number
        ch[target_ch - 1] = pwm_value              # convert to 0-based index

        self.pixhawk.send_rc_override(
            ch[0], ch[1], ch[2], ch[3],
            ch[4], ch[5], ch[6], ch[7],
        )